## Author
Vikas Gola
2016UCS0023

## Src
"src" folder contains all required Programs for assignments.

## Exectuable
All exectuable files of all programs related to question is in folders with the name of question e.g. question 1 executables are in folder "Question 1".


## How to run
Please follow all these commands in folders of Question. You will find the port number on which all servers will run after running the program. However mostly run on 9923.
If you find some details here, please run client by "./client" program then you will get "How to use". 


Question 1 : run "./printip hostname1 hostname2 ..." on terminal and it will ask for your ip address and shows you ip address of hostnames.

Question 2 : run "./server" to start the server and then run client "./client ip/hostname".

Question 3 : run "./server" to start the server and then run client "./client ipaddress port_number/helloservice".

Question 4 : run "./server" to start the server and then run client "./client ipaddress/helloservice".

Question 5 : run "./server" to start the server and then run client "./client ipaddress".

Question 6 : run "./server" to start the server and then run client "./client ipaddress port_number".


Question 8: run "./server" to start the ftp server and then run client "./client ipaddress".


Question 9 : run "make" to compile the server program and then run server "./server". Now, you can send http request to server by opening browser at "localhost:9923" or using http client program.


Question 10 : run "./server" to start the server and then run client "./client ip/hostname port_number".


Question 11 : run "./client ip/hostname port GET filename" to use http client.


